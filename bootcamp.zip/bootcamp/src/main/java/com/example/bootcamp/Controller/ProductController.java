package com.example.bootcamp.Controller;


import com.example.bootcamp.Configuration.ProducerConfig;
import com.example.bootcamp.Repository.EmployeeRepository;
import com.example.bootcamp.Repository.EmployeeSkillRepository;
import com.example.bootcamp.model.Empployee;
import com.example.bootcamp.model.Employee_Skill;
import com.example.bootcamp.model.EmployeeInformation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ProductController {

//    @Autowired
//    ProductRepository productRepository;
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    EmployeeSkillRepository employeeSkillRepository;
    private final ProducerConfig producerConfig;

    public ProductController(ProducerConfig producerConfig) {
        this.producerConfig = producerConfig;
    }

    @PostMapping("/createEmployee")
    public EmployeeInformation createEmployeeInfo(@RequestBody EmployeeInformation employeeInformation) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        Empployee empployee = new Empployee(employeeInformation.getEmp_id(),
                employeeInformation.getEmp_name(), employeeInformation.getEmp_city(),
                employeeInformation.getEmp_phone());
        Employee_Skill emp_skill = new Employee_Skill(employeeInformation.getEmp_id(),
                employeeInformation.getJava_exp(), employeeInformation.getSpring_exp());
        boolean empIsPresent =  employeeRepository.findById(employeeInformation.getEmp_id()).isPresent();
        if(empIsPresent){
            employeeInformation.setStatus("Already Exists");
        } else {
            employeeInformation.setStatus("Created");
        }
        employeeRepository.save(empployee);
        employeeSkillRepository.save(emp_skill);
        String kafkaMessage = mapper.writeValueAsString(employeeInformation);
        this.producerConfig.writeMessage(kafkaMessage);

//        KafkaProducer<String, String> first_producer = new

        return employeeInformation;

    }
//
//    @PostMapping("/products")
//    public Product addProduct(@RequestBody Product product){
//        productRepository.save(product);
//        return product;
//
//    }
//
//    @GetMapping("/products/{id}")
//    public ResponseEntity<Product> findById(@PathVariable("id") Integer productId){
//        Product product=productRepository.findById(productId).orElseThrow(
//                () -> new ResouceNotFoundException("Product not found" + productId));
//        return ResponseEntity.ok().body(product);
//    }
//
//
//
//    @GetMapping("/products")
//    public List<Product> getProducts(){
//
//        return productRepository.findAll();
//    }
//
//    @PutMapping("products/{id}")
//    public ResponseEntity<Product> updateProduct(@PathVariable(value = "id") Integer productId,
//                                                  @RequestBody Product productDetails) {
//        Product product = productRepository.findById(productId)
//                .orElseThrow(() -> new ResouceNotFoundException("Product not found for this id :: " + productId));
//        product.setName(productDetails.getName());
//        final Product updatedProduct = productRepository.save(product);
//        return ResponseEntity.ok(updatedProduct);
//
//    }
//
//    @DeleteMapping("products/{id}")
//    public ResponseEntity<Void> deleteProduct(@PathVariable(value = "id") Integer productId) {
//        Product product = productRepository.findById(productId).orElseThrow(
//                () -> new ResouceNotFoundException("Product not found::: " + productId));
//        productRepository.delete(product);
//        return ResponseEntity.ok().build();
//    }

}


