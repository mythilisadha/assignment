package com.example.bootcamp.Repository;

import com.example.bootcamp.model.Employee_Skill;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface EmployeeSkillRepository extends CassandraRepository<Employee_Skill, Double> {
}
