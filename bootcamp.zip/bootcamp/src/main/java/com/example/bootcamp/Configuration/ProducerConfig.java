package com.example.bootcamp.Configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerConfig {

    private  static final String TOPIC = "my_topic";
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void writeMessage(String message) {
        this.kafkaTemplate.send(TOPIC, message);
    }
}
